from pyspark.sql import SparkSession
from pyspark.sql.functions import col, current_date, year, month, dayofmonth

# Initialize Spark session
spark = SparkSession.builder \
    .master("local[2]") \
    .appName("Hackathon") \
    .enableHiveSupport() \
    .getOrCreate()

# Load CSV file into DataFrame
df_1 = spark.read.csv("file:///home/hduser/Desktop/Hackathon/manuf_data.csv", header=True, inferSchema=True)

# Show initial DataFrame
print("Initial DataFrame:")
df_1.show(1)

# Data munging - Remove rows with missing values
df_clean = df_1.dropna()

# Rename columns to match schema
df_final = df_clean.withColumnRenamed("station_id2", "station_id")

# Show DataFrame after cleaning and renaming columns
print("DataFrame after cleaning and renaming columns:")
df_final.show(1)

# Data enrichment - Add current date and extract additional features
df_enriched = df_final.withColumn("Current_Date", current_date()) \
                      .withColumn("Year", year(col("Current_Date"))) \
                      .withColumn("Month", month(col("Current_Date"))) \
                      .withColumn("Day", dayofmonth(col("Current_Date")))

# Show enriched DataFrame
print("Enriched DataFrame:")
df_enriched.show(1)

